package com.example.clothesshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClothesShopApplicationTests {

    @Test
    void contextLoads() {
    }

}
