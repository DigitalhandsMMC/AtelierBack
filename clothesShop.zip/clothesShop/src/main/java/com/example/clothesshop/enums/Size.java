package com.example.clothesshop.enums;

public enum Size {
    XS, S, M, L, XL
}
