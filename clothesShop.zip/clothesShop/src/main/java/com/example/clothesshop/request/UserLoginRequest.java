package com.example.clothesshop.request;

import lombok.Data;

@Data
public class UserLoginRequest {

    private String email;
    private String password;

}
