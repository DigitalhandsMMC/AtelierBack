package com.example.clothesshop.file_upload_for_blog_post.exception;

public class FileNotFoundException extends RuntimeException {

    public FileNotFoundException(String message) {
        super(message);
    }

}