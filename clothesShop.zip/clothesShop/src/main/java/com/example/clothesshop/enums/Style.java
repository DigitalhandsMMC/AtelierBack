package com.example.clothesshop.enums;

public enum Style {
    COCKTAIL, EVENING
}
