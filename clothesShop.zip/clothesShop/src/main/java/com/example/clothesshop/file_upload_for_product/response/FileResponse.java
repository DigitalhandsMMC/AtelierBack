package com.example.clothesshop.file_upload_for_product.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FileResponse {

    private Long id;

    private String name;
    private String contentType;
    private byte[] fileData;

}