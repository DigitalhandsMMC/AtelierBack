package com.example.clothesshop.exception.error;

public class ErrorMessage {

    public static final String BLOG_POST_NOT_FOUND = "Blog post not found : ";

}