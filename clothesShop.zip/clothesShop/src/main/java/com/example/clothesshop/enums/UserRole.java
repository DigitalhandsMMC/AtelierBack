package com.example.clothesshop.enums;

public enum UserRole {
    ADMIN, USER
}
