package com.example.clothesshop.enums;

    public enum PropertyType
    {
        BUYING, RENT
    }


