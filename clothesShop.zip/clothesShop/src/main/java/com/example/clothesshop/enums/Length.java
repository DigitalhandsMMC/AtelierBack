package com.example.clothesshop.enums;

public enum Length {
    SHORT, LONG
}
